

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
  
    
    @IBOutlet weak var paymentLabel: UILabel!
    
    @IBOutlet weak var paymentImage: UIImageView!
    
    
    
}
